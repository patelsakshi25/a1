const express = require("express");

const app = express();
const PORT = 8000;


app.get("/google", async (req, res) => {
    try {
        const response = await fetch("https://www.google.com");
        const data = await response.text();

        res.send(data);
    } catch (err) {
        res.status(500).send("Error: " + err.message);
    }
});

app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});