const fs = require("fs");
const archiver = require("archiver");

const output = fs.createWriteStream("MyFolder.zip");

const archive = archiver("zip", {
    zlib: { level: 9 }
});

output.on("close", () => {
    console.log("ZIP file created successfully!");
    console.log("Total Size:", archive.pointer(), "bytes");
});

archive.on("error", (err) => {
    throw err;
});

archive.pipe(output);
archive.directory("MyFolder/", false);
archive.finalize();