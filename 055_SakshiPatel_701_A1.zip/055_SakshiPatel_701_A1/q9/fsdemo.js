const fs = require("fs");

// 1. Create and write to a file
fs.writeFileSync("sample.txt", "Hello Node.js!");

// 2. Read the file
const data = fs.readFileSync("sample.txt", "utf8");
console.log("File Content:", data);

// 3. Append data to the file
fs.appendFileSync("sample.txt", "\nWelcome to File System Module.");

// 4. Rename the file
fs.renameSync("sample.txt", "newfile.txt");

// 5. Check if file exists
if (fs.existsSync("newfile.txt")) {
    console.log("File exists.");
}

// 6. Get file information
const stats = fs.statSync("newfile.txt");
console.log("File Size:", stats.size, "bytes");

// 7. Copy the file
fs.copyFileSync("newfile.txt", "copy.txt");
console.log("File copied successfully.");

// 8. Delete copied file
fs.unlinkSync("copy.txt");
console.log("Copied file deleted.");