// Task 1
function task1() {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            console.log("Task 1: Student Record Created");
            resolve("Student Record");
        }, 1000);
    });
}

// Task 2 (depends on Task 1)
function task2(data) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            console.log("Task 2: Fee Paid for", data);
            resolve("Fee Payment");
        }, 1000);
    });
}

// Task 3 (depends on Task 2)
function task3(data) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            console.log("Task 3: ID Card Generated after", data);
            resolve("Completed");
        }, 1000);
    });
}

// Chained Promises
task1()
    .then(task2)
    .then(task3)
    .then((result) => {
        console.log("All Tasks Completed Successfully!");
    })
    .catch((err) => {
        console.log("Error:", err);
    });