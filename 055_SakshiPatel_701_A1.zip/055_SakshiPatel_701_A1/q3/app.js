const readline = require("readline");
const chatbot = require("./chatbot");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

console.log("=== College Chatbot ===");
console.log("Type your question (type 'bye' to exit)");

function chat() {
    rl.question("You: ", (message) => {

        const reply = chatbot.getResponse(message);
        console.log("Bot:", reply);

        if (message.toLowerCase() === "bye") {
            rl.close();
        } else {
            chat();
        }
    });
}

chat();