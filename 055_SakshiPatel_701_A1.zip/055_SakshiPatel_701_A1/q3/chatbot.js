function getResponse(message) {
    message = message.toLowerCase();

    if (message.includes("hello") || message.includes("hi")) {
        return "Hello! Welcome to ABC College.";
    }
    else if (message.includes("course")) {
        return "We offer BSc IT, BCA, BCom and BBA.";
    }
    else if (message.includes("admission")) {
        return "Admissions are open from May to July.";
    }
    else if (message.includes("fees")) {
        return "Please contact the Accounts Office for fee details.";
    }
    else if (message.includes("library")) {
        return "The library is open from 9:00 AM to 5:00 PM.";
    }
    else if (message.includes("bye")) {
        return "Thank you! Have a nice day.";
    }
    else {
        return "Sorry, I don't understand your question.";
    }
}

module.exports = { getResponse };