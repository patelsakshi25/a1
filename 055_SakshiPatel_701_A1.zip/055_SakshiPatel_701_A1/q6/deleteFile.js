const fs = require("fs");
const util = require("util");

const unlinkAsync = util.promisify(fs.unlink);

unlinkAsync("sample.txt")
    .then(() => {
        console.log("File deleted successfully!");
    })
    .catch((err) => {
        console.log("Error:", err.message);
    });