const express = require("express");
const path = require("path");

const app = express();
const PORT = 8000;

// Serve HTML file
app.use(express.static(path.join(__dirname, "public")));

// GET Route
app.get("/gethello", (req, res) => {
    res.send("Hello NodeJS!!");
});

app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});