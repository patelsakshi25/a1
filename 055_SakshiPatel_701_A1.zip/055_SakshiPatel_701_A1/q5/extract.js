const fs = require("fs");
const unzipper = require("unzipper");


fs.createReadStream("MyFolder.zip")
    .pipe(unzipper.Extract({ path: "ExtractedFiles" }))
    .on("close", () => {
        console.log("ZIP file extracted successfully!");
    })
    .on("error", (err) => {
        console.log("Error:", err);
    });